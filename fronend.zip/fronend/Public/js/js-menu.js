$('#x').click(function(){
	$('#y').toggle(500);
});

$('#z').click(function(){
	$('#k').toggle(500);
});

$('#main-control').click(function(){
	$('#none-menu').toggle(500);
});