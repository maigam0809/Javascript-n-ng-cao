import CategoryAPI from "../api/categoryAPI";

const Header ={
    async render(){
        const {data: categories} = await CategoryAPI.getAll();
        // console.log(categories);
        // return /*html*/`
        
        // <div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom box-shadow">
        //     <h5 class="my-0 mr-md-auto font-weight-normal">Company name</h5>
        //     <nav class="my-2 my-md-0 mr-md-3">
        //     <a class="p-2 text-dark" href="/">HomePage</a>
        //     <a class="p-2 text-dark" href="/#/products">Products</a>
        //     ${
        //         categories.map(category=>{
        //             return `
        //             <a class="p-2 text-dark" href="/#/categories/${category.id}">${category.name}</a>
        //             `
        //         }).join("")
        //     }
        //     <a class="p-2 text-dark" href="#">ProductDetail</a>
        //     <a class="p-2 text-dark" href="#">Pricing</a>
        //     </nav>

        //     <a class="btn btn-outline-primary" href="#">Sign up</a>
        // </div>
        
        // `
         return /*html*/`
         <li><a href="categories.html"><img class="hiden-none" src="public/images/icon/i_menu_1.png" alt="">
         ${
                 categories.map(category=>{
                     return `
                     <a class="p-2 text-dark" href="/#/categories/${category.id}">${category.name}</a>
                     `
                 }).join("")
             }
        </a></li>
        <!-- <li><a href="#"><img class="hiden-none" src="public/images/icon/i_menu_2.png" alt="">Hải sản</a></li>
        <li><a href="#"><img class="hiden-none" src="public/images/icon/i_menu_3.png" alt="">Hoa quả trong
                nước</a></li>
        <li><a href="#"><img class="hiden-none" src="public/images/icon/i_menu_4.png" alt="">Hoa quả nhập
                khẩu</a></li>
        <li class="hiden-none"><a href="#"><img src="public/images/icon/i_menu_5.png" alt="">Hoa quả sấy</a>
        </li>
        <li class="hiden-none"><a href="#"><img src="public/images/icon/i_menu_6.png" alt="">Thịt các loại</a>
        </li> -->
        
         <!-- <div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom box-shadow">
             <h5 class="my-0 mr-md-auto font-weight-normal">Company name</h5>
             <nav class="my-2 my-md-0 mr-md-3">
             <a class="p-2 text-dark" href="/">HomePage</a>
             <a class="p-2 text-dark" href="/#/products">Products</a>
             ${
                 categories.map(category=>{
                     return `
                     <a class="p-2 text-dark" href="/#/categories/${category.id}">${category.name}</a>
                     `
                 }).join("")
             }
             <a class="p-2 text-dark" href="#">ProductDetail</a>
             <a class="p-2 text-dark" href="#">Pricing</a>
             </nav>
 
             <a class="btn btn-outline-primary" href="#">Sign up</a>
         </div> -->
         
         `
    }
}
export default Header;