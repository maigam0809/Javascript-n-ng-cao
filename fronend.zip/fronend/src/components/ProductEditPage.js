import productAPI from '../api/productAPI';
import {parseRequestUrl, $} from '../untils';
const ProductEditPage ={
    async render(){
        const {id} = parseRequestUrl();
        const {data:product} = await productAPI.get(id);
        // console.log(id);
        // console.log(product);

        return /*html*/`
            <form id="form-update-product">
                <div class="mb-3">
                    <label for="product_name" class="form-label">Tên Sản Phẩm</label>
                    <input type="text" class="form-control" id="product_name"value="${product.name}" aria-describedby="emailHelp">
                </div>
                <!-- <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1">
                </div> -->
                <!-- <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                    <label class="form-check-label" for="exampleCheck1">Check me out</label>
                </div> -->
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        `;

    }
    ,
    async afterRender(){
        const {id} = parseRequestUrl();
        const {data:product} = await productAPI.get(id);
        // console.log(id);
        // console.log(product);
        $('#form-update-product').addEventListener('submit', e =>{ 
            e.preventDefault()
            // console.log('Before',product);
           const newProduct = {
               // id : random,
               ...product,
               name : $('#product_name').value
           }
        //    console.log(newProduct);
        // console.log('after',newProduct);
        productAPI.update(id,newProduct);

        window.location.hash = '/listproducts';
       })
    }
}
export default ProductEditPage;