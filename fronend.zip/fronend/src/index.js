import HomePage from './pages/HomePage.js';
import ProductsPage from './pages/ProductsPage.js';
import ProductDetail from './pages/ProductDetail.js';
import { parseRequestUrl , $} from './untils.js';
import Error404 from './pages/Error404Page.js';
import Header from './components/Header.js';
import Footer from './components/Footer.js';
import CategoryPage from './pages/CategoryPage.js';
import ProductAddPage from './pages/AddProduct.js';
import AdminProductsPage from './pages/AdminProductPage.js';
import ProductEditPage from './components/ProductEditPage.js';

// const $ = selector =>{
//     let elements = document.querySelectorAll(selector);
//     return elements.length == 1 ? elements[0] : [...elements];
// }

const routers ={
    '/': HomePage,
    '/products': ProductsPage,
    '/products/:id': ProductDetail,
    '/categories/:id': CategoryPage,
    '/addproducts': ProductAddPage,
    '/listproducts': AdminProductsPage,
    '/listcate': ProductEditPage,
    // '/editproducts/:id': ProductEditPage,
    // '/editproducts/:id': ProductEditPage,
}


const router = async()=> {
    const { resource, id} =  parseRequestUrl();
    // console.log(parseRequestUrl());
    // console.log(id);

    const parseUrl = (resource ? `/${resource}` : '/' ) +
                    (id ? `/:id`: '');
    
    // console.log(parseUrl);
    const page =  routers[parseUrl] ? routers[parseUrl] : Error404;
    // console.log(page);

    $('#header').innerHTML = await Header.render();
    $('#main-content').innerHTML = await page.render();
    await page.afterRender();
    $('#footer').innerHTML = await Footer.render();
    // $('#main-content').innerHTML = ProductsPage.render();
}

window.addEventListener('DOMContentLoaded',router);
window.addEventListener('hashchange',router);
// $('#main-content').innerHTML = HomePage.render();

