import CategoryAPI from '../CategoryAPI.js';
import { $ } from '../untils.js';
// import firebase from "../firebase";

const CateAddPage ={
    async render(){
        return /*html*/`
        <form class="form"  id="form-add" method="post">
            <div class="form-group">
                <label for="cate_name" class="form-label">Tên Loại</label>
                <input type="text" class="form-control" placeholder="Tên sản phẩm" id ="cate_name"/>
            </div>
            <div class="form-group">
                <label for="cate_image" class="form-label">Ảnh</label>
                <input type="file" class="form-control" placeholder="Ảnh sản phẩm" id ="cate_image"/>
            </div>
            <div class="form-group btn">
                <input type="submit" class="form-control" value="add product"/>
            </div>

        <form>
        
        `;
    },
    async afterRender(){
         $('#form-add').addEventListener('submit', e =>{ 
             e.preventDefault()
            //  const productImage = $('#product_image').files[0];
            //  console.log(productImage);
            // let storageRef =  firebase.storage().ref(`image/${productImage.name}`);
            // console.log(storegaref);
            // storageRef.put(productImage).then(function(){
            //     console.log('upload thành công');
            // });
            //  let file = productImage.files[0];
            //  console.log('hello');
            
            const product = {
                // id : random,
                name : $('#cate_name').value
            }
            // console.log(product);
            ProductApi.add(product)
        })

    }
}
export default ProductAddPage;