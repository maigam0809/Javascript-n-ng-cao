import { parseRequestUrl } from "../untils";
import productAPI from "../api/productAPI";


const CategoryPage = {
    async render(){
        
        const {id}  = parseRequestUrl();
        // console.log(id);

        const {data: products} = await productAPI.getAll();
        // const {id} = parseRequestUrl();
        // console.log(products);
        
        const result = products.filter(product => product.categoryId == id).map(product=>{
                            return  /*html*/`
                                <div> 
                                <a href="/#/products/${product.id}">${product.name}</a>
                                </div>
                            `;
                        }).join("");
        return `${result}`;
    }
}
export default CategoryPage;