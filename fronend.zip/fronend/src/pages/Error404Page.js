const Error404 ={
    render(){
        return '<h1> Lỗi 404 </h1>';
    }
}

export default Error404;