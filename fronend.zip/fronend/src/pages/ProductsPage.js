// import data from '../data.js';
// console.log(data.products);
import productAPI from '../api/productAPI';

import axios from "axios";

const ProductsPage ={
    async render(){
        // const {products} = data;
        try {
            const {data: products} = await productAPI.getAll();
            // console.log(response);
            // const response = await axios('https://603778fe54350400177227c5.mockapi.io/products');
            // const products = await response.data;
            const result = products.map(product=>{
                // console.log(product);
                return `
                    <div class="col-4">
                        <div class="card">
                            <img class="card-img-top" src="${product.image}" alt="${product.image}">
                            <div class="card-body">
                                <h5 class="card-title">${product.name}</h5>
                                <p class="card-text">${product.price}</p>
                                <a href="/#/products/${product.id}" class="btn btn-primary">Go somewhere</a>
                            </div>
                        </div>
                    </div>
                `;
            }).join("")
            console.log(result);
            return `
                <h1>Products Page</h1>
                <div class="row"> 
                    ${result}
                </div>
                `;
        } catch (error) {
            console.log("error404");
        }
        
    }
}

export default ProductsPage;