import ProductApi from '../api/productAPI.js';
import { $ } from '../untils.js';
// import firebase from "../firebase";

const ProductAddPage ={
    async render(){
        return /*html*/`
        <form class="form"  id="form-add" method="post">
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Tên sản phẩm" id ="product_name"/>
            </div>
            <div class="form-group">
                <input type="file" class="form-control" placeholder="Ảnh sản phẩm" id ="product_image"/>
            </div>
            <div class="form-group btn">
                <input type="submit" class="form-control" value="add product"/>
            </div>

        <form>
        
        `;
    },
    async afterRender(){
         $('#form-add').addEventListener('submit', e =>{ 
             e.preventDefault()
            //  const productImage = $('#product_image').files[0];
            //  console.log(productImage);
            // let storageRef =  firebase.storage().ref(`image/${productImage.name}`);
            // console.log(storegaref);
            // storageRef.put(productImage).then(function(){
            //     console.log('upload thành công');
            // });
            //  let file = productImage.files[0];
            //  console.log('hello');
            
            const product = {
                // id : random,
                name : $('#product_name').value
            }
            // console.log(product);
            ProductApi.add(product)
        })

    }
}
export default ProductAddPage;