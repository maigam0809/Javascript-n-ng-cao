// import data from '../data.js';
// import axios from 'axios';
import { parseRequestUrl } from '../untils.js';

import productAPI from '../api/productAPI';

const ProductDetail ={
    async render(){
        
        // const {products} = data;
        // const response = await axios('https://603778fe54350400177227c5.mockapi.io/products');
        // console.log(response);
        // const products = await response.data;
        // const request = parseRequestUrl();
        // console.log(request.id);
        const {id} = parseRequestUrl();
        const {data:product} = await productAPI.get(id);

        // console.log(id);

        // const product = products.find(
        //     // product => product.id == request.id
        //     product => product.id == id
        // )
        // console.log(product);

        return `
        <div class="row"> 
            <div class="col-6"> 
                <img src="${product.image}" alt="">
            </div>
            <div class="col-6"> 
                <h1>${product.name} </h1>

            </div>
        </div>
            `;
    }
}
export default ProductDetail;