// For Firebase JS SDK v7.20.0 and later, measurementId is optional
// import firebase from '../firebase';

const firebase = {
        apiKey: "AIzaSyAAI836I2VQiVMw974s73pboFSzYJZBJnA",
        authDomain: "shopping-online-83635.firebaseapp.com",
        projectId: "shopping-online-83635",
        storageBucket: "shopping-online-83635.appspot.com",
        messagingSenderId: "450046403838",
        appId: "1:450046403838:web:967f56e929670a5da9f1af",
        measurementId: "G-L0WCTYWT15"
};


export default firebase;